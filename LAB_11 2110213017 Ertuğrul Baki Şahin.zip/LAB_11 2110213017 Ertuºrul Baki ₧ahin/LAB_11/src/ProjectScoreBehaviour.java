public interface ProjectScoreBehaviour {
    float projectScore();
}
