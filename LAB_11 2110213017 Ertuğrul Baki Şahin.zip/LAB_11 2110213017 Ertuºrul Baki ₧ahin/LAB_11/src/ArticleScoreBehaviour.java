public interface ArticleScoreBehaviour {
      float articleScore();
}
