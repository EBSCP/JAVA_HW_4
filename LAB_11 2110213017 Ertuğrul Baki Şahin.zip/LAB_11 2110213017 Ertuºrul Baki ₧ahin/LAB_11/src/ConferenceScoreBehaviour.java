public interface ConferenceScoreBehaviour {
    float ConferenceScore();
}
