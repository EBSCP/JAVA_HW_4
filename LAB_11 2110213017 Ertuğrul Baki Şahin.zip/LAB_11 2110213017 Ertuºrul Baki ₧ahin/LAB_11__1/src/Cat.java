public class Cat extends Animal implements Swimable {
    @Override
    public void swim() {
        System.out.println("The cat is swimming");
    }


}
