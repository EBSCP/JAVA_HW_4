public interface Moveable {
    void move();
}
