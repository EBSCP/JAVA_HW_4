public interface Swimable {
    void swim();
}
