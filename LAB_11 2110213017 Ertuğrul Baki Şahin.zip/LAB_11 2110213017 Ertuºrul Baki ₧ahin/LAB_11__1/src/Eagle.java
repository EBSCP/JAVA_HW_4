public class Eagle  extends  Animal implements Flyable{
    @Override
    public void fly() {
        System.out.println("Flying");
    }
}
