public abstract class Animal {
    public  String Name;
}
