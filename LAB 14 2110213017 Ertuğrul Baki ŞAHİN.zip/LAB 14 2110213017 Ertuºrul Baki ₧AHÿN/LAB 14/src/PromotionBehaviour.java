public interface PromotionBehaviour {
    double getPromotion();
}
