public interface BonusSalaryBehaviour {
    double getBonusSalary();
}
